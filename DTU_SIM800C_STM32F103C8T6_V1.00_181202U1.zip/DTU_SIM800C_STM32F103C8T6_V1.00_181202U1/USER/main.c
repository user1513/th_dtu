#include "sys.h"
#include "usart.h"		
#include "delay.h"	 

#include "led.h"
#include "sim800c.h"
#include "mb85rcxx.h"

#include "usart3.h"
#include "malloc.h"

#include "dtu_main.h"
#include "serialnum.h"


u32 SerialNum[3];

int main(void)
{				 
	
	Stm32_Clock_Init(9);	//ϵͳʱ������
	delay_init(72);	  		//��ʱ��ʼ��
	uart_init(72,115200); 	//���ڳ�ʼ��Ϊ115200	//debug
	
	//usart3_init(36,115200);	//485
	
	LED_Init();
	
	MB85RCXX_Init();
	
	SIM800C_Init();
	
	my_mem_init(SRAMIN);		                    //��ʼ���ڲ��ڴ��
	
	Get_SerialNum(SerialNum);
	//MB85RCXX_BIT_TEST();
	//MB85RCXX_Page_TEST();
		
	DTU_main();
	
	return 0;
} 






