
#ifndef	_SIM800C_H_
#define	_SIM800C_H_


#include "sys.h"


#define SIM800_PWRKEY	PAout(4)



#define SIM800_PWRKEY_HIGH()	SIM800_PWRKEY = 1
#define SIM800_PWRKEY_LOW()		SIM800_PWRKEY = 0

#define SIM800C_Tx GPIO_Pin_2
#define SIM800C_Tx_PORT GPIOA

#define SIM800C_Rx GPIO_Pin_3
#define SIM800C_Rx_PORT GPIOA

void SIM800C_Init(void);
void SIM800C_IO_Init(void);
void SIM800C_PWR_ON(void);
void SIM800C_PWR_OFF(void);
void SIM800C_RESTART(void);

void sim_at_response(u8 mode);
u8* sim800c_check_cmd(u8 *str);
u8 sim800c_send_cmd(u8 *cmd,u8 *ack,u16 waittime);
void ntp_update(void);

u8 sim800c_gprs_config(u8 mode,u8* ipaddr,u8* port);

#endif 
