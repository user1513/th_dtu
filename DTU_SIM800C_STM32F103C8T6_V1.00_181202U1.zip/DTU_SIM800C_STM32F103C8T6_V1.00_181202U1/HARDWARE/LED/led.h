#ifndef __LED_H
#define __LED_H

#include "sys.h"

#define LED1	PBout(9)
#define LED2	PBout(8)

void LED_Init(void);//IO��ʼ��
	

#endif
