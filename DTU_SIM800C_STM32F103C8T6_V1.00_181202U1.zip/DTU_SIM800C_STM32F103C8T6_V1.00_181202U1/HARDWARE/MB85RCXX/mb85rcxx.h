#ifndef __MB85RC_H
#define __MB85RC_H

#include "mb85rcxx_iic.h"


#define MB85RC01	127
#define MB85RC02	255
#define MB85RC04	511
#define MB85RC08	1023
#define MB85RC16	2047			//2048words * 8bit
#define MB85RC64	8191			//8192words * 8bit
#define MB85RC128	16383
#define MB85RC256	32767

//ʹ��EE_TYPEΪMB85RC16
#define EE_TYPE MB85RC16

//#define WP_SET          PBin(2)=1 //д�����˿� ��ֹд��
//#define WP_CLR          PBin(2)=0 //д�����˿� ����д��

void MB85RCXX_Init(void);
void MB85RCXX_WriteOneByte(u8 Page,u16 WriteAddr,u8 DataToWrite);
u8 MB85RCXX_ReadOneByte(u8 Page,u16 ReadAddr);
void MB85RCXX_Write(u16 WriteAddr,u8 *pBuffer,u16 NumToWrite);
void MB85RCXX_Read(u16 ReadAddr,u8 *pBuffer,u16 NumToRead);

void MB85RCXX_BIT_TEST(void);
void MB85RCXX_Page_TEST(void);
/*

void WriteEeprom(u8 Page,u8 EeAddr,u16 * WriteAddr,u8 Number);
void ReadEeprom(u8 Page,u8 EeAddr,u16 * ReadArray,u8 Number);
void WriteEeprom_char(u8 Page,u8 EeAddr,u8 * WriteAddr,u8 Number);
void ReadEeprom_char(u8 Page,u8 EeAddr,u8 * ReadArray,u8 Number);	
*/

#endif
