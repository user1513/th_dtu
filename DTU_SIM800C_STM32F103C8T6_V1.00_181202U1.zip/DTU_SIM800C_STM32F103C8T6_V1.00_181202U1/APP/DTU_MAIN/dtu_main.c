#include "dtu_main.h"
#include "dtu_at.h"
#include "dtu_gprs.h"
#include "dtu_sms.h"
#include "dtu_bt.h"
#include "dtu_fram.h"



u8	DTU_RUNMODE 		= 	DTU_GPRS_TCP;

u32	DTU_BAUDRATE		=	115200;

u8	DTU_HEART_EN 		= 	1;						//1��ʹ�� 
u32	DTU_HEART_TIME 		= 	30;
u8	DTU_HEART_DATA[100]	=	"www.ruibake.com";

u8	DTU_CMD_PW[20]		=	"ruibake.com";

u8	DTU_START_EN		=	1;
u8	DTU_START_LOG[20]	=	"ruibake DTU";

u8	DTU_TCP_IPADDR[100]	=	"tangwa002.f3322.net";
u8	DTU_TCP_PORT[6]		=	"30000";

u8	DTU_UDP_IPADDR[100]	=	"tangwa002.f3322.net";
u8	DTU_UDP_PORT[6]		=	"31000";

u8	DTU_SMS_PHONE[20]	=	"18752028956";

u8	DTU_BT_NAME[10]		=	"RBK_DTU";

u8	DTU_NATEN			=	1;
u8	DTU_UATEN			=	1;





void DTU_setup(void)
{
	
	while(sim800c_send_cmd("AT","OK",100))				//����Ƿ�Ӧ��ATָ�� 
	{
		printf("δ��⵽ģ��!!!\r\n");
		delay_ms(800);
		printf("��������ģ��...\r\n");
		delay_ms(400);  
	}
	
	sim800c_send_cmd("ATE0","OK",200);					//������
	
	sim800c_send_cmd("AT+CSQ","+CSQ:",200);				//��ѯ�ź�����
	
	DTU_NTP_Update();									//����ͬ��ʱ��
	
	printf("dtu work...\r\n");
	
	//DTU_GPRS_TCP_WORK();
	//DTU_SMS_WORK();
	
	//DTU_FRAM_Read();
	//DTU_FRAM_Write();
	DTU_FRAM_Read();
	
	if((DTU_RUNMODE%10 !=DTU_GPRS_TCP)&&(DTU_RUNMODE%10 !=DTU_GPRS_UDP)&&(DTU_RUNMODE%10 !=DTU_SMS)&&(DTU_RUNMODE%10 != DTU_BT)&&(DTU_RUNMODE/10 != DTU_AT))
	{
		//�ָ���������
		DTU_FRAM_Reset_Admin();
	}
	
	usart3_init(36,DTU_BAUDRATE);	//485
	
	//DTU_RUNMODE = DTU_GPRS_TCP;
	
	if(DTU_RUNMODE/10 > 1)
	{
		DTU_RUNMODE = DTU_RUNMODE - (DTU_RUNMODE/10)*10;
	}
}


void DTU_loop(void)
{
	if(DTU_RUNMODE/10 >= 1)
	{
		DTU_AT_WORK();
	}else
	{
		switch(DTU_RUNMODE)
		{
			case DTU_AT:				//ATģʽ
				DTU_AT_WORK();
				break;
			
			case DTU_GPRS_TCP:			//GPRS TCPģʽ
				DTU_GPRS_TCP_WORK();
				break;
			
			case DTU_GPRS_UDP:			//GPRS UDPģʽ
				DTU_GPRS_UDP_WORK();
				break;

			case DTU_SMS:				//SMS ģʽ
				DTU_SMS_WORK();
				break;

			case DTU_BT:				//����SPPģʽ
				DTU_SPP_WORK();
				break;
			
			default:
				break;
		}			
	}
}



//����Ķ�
void DTU_main(void)
{
	DTU_setup();
	
	while(1)
	{
		DTU_loop();
	}
}
