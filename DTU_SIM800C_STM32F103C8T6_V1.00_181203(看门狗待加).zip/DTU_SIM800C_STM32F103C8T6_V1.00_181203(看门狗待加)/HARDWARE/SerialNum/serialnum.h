#ifndef __SERIALNUM_H
#define __SERIALNUM_H 

void Get_SerialNum(unsigned int* SerialID);

#endif

