#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"


void TIM3_Int_Init(u16 arr,u16 psc);

void TIM4_Int_Init(u16 arr,u16 psc);
void TIM4_SetARR(u16 period);

void TIM2_Int_Init(u16 arr,u16 psc);
void TIM2_SetARR(u16 period);
#endif























