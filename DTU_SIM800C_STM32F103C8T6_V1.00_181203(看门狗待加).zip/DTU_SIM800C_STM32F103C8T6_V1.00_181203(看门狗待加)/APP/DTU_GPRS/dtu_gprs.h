#ifndef	_DTU_GPRS_H_
#define	_DTU_GPRS_H_


void DTU_GPRS_TCP_WORK(void);
void DTU_GPRS_UDP_WORK(void);

void dtu_gprs_printf(char* fmt);
#endif 
