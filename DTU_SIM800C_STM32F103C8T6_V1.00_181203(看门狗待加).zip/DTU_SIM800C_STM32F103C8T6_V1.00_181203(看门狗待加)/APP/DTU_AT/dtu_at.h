#ifndef	_DTU_AT_H_
#define	_DTU_AT_H_

#include "dtu_main.h"

extern u8 at_type;


u8 DTU_AT_Check(void);

void DTU_NTP_Update(void);

void DTU_AT_WORK(void);

u8 UAT_AT_CMD(void);

u8 NET_AT_CMD(u8 *pbuff);

#endif 
