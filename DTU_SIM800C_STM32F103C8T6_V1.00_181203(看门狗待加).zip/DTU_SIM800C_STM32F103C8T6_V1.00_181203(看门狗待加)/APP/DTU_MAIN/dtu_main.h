#ifndef	_DTU_MAIN_H_
#define	_DTU_MAIN_H_

#include "delay.h"
#include <string.h>

#include "usart2.h"
#include "usart3.h"
#include "timer.h"
#include "malloc.h"
#include "sim800c.h"
#include "wdg.h"

#define DTU_VERSION	"RBKSIM800CV1.00_20181202U1"


#define swap16(x) (x&0XFF)<<8|(x&0XFF00)>>8	//�ߵ��ֽڽ����궨��


#define DTU_AT			10

#define DTU_GPRS_TCP	1
#define DTU_GPRS_UDP	2

#define DTU_SMS			5
#define DTU_BT			6


extern u8	DTU_RUNMODE;
extern u32	DTU_BAUDRATE;
extern u8	DTU_HEART_EN;						//1��ʹ�� 
extern u32	DTU_HEART_TIME;
extern u8	DTU_HEART_DATA[100];
extern u8	DTU_CMD_PW[20];
extern u8	DTU_START_EN;
extern u8	DTU_START_LOG[20];
extern u8	DTU_TCP_IPADDR[100];
extern u8	DTU_TCP_PORT[6];
extern u8	DTU_UDP_IPADDR[100];
extern u8	DTU_UDP_PORT[6];
extern u8	DTU_SMS_PHONE[20];
extern u8 	DTU_BT_NAME[10];
extern u8	DTU_NATEN;
extern u8	DTU_UATEN;

void DTU_main(void);

#endif 
