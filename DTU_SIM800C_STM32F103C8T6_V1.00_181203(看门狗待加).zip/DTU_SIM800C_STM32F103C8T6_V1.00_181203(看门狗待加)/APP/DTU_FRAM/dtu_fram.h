#ifndef	_DTU_FRAM_H_
#define	_DTU_FRAM_H_

#include "mb85rcxx.h"


void DTU_FRAM_Reset_Admin(void);
void DTU_FRAM_Reset_User_Read(void);
void DTU_FRAM_Reset_User_Write(void);
void DTU_FRAM_Read(void);
void DTU_FRAM_Write(void);

#endif 
