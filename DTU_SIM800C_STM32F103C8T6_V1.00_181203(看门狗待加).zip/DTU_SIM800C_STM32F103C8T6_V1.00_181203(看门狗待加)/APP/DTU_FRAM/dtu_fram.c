#include "dtu_fram.h"
#include "dtu_main.h"

#define WKMOD_ADDR			0	//1���ֽ�
#define BAUDRATE_ADDR		1	//4���ֽ�

#define HEART_EN_ADDR		5	//1���ֽ�
#define HEART_TIME_ADDR		6	//4
#define HEART_DATA_ADDR		10	//100���ֽ�

#define CMD_PW_ADDR			110	//20���ֽ�

#define START_EN_ADDR		130	//1���ֽ�
#define START_LOG_ADDR		131	//20���ֽ�

#define TCP_IPADDR_ADDR		151	//100���ֽ�
#define TCP_PORT_ADDR		251	//6���ֽ�

#define UDP_IPADDR_ADDR		257	//100���ֽ�
#define UDP_PORT_ADDR		357	//6���ֽ�

#define DTU_SMS_PHONE_ADDR	363	//20���ֽ�
#define DTU_BT_NAME_ADDR	383	//10���ֽ�

#define DTU_NATEN_ADDR		393	//1���ֽ�
#define DTU_UATEN_ADDR		394	//1���ֽ�


u8 deviation = 0;				//ƫ��	0��Ĭ��	1���û��洢��	2����������
//0-1 2-3 4-5
u8 FRAM_ReadOneByte(u16 address)
{
	return MB85RCXX_ReadOneByte((address>>8)+deviation*2,address&0x00FF);
}

void FRAM_WriteOneByte(u16 address,u8 data)
{
	MB85RCXX_WriteOneByte((address>>8)+deviation*2,address&0x00FF,data);
}

//��FRAM�����ָ����ַ��ʼд��ָ������������
//WriteAddr :��ʼд��ĵ�ַ
//pBuffer   :���������׵�ַ
//NumToWrite:Ҫд�����ݵĸ���
void FRAM_Write(u16 WriteAddr,u8 *pBuffer,u16 NumToWrite)
{
	while(NumToWrite--)
	{
		FRAM_WriteOneByte(WriteAddr,*pBuffer);
		WriteAddr++;
		pBuffer++;
	}
}

//��FRAM�����ָ����ַ��ʼ����ָ������������
//ReadAddr :��ʼ�����ĵ�ַ
//pBuffer  :���������׵�ַ
//NumToRead:Ҫ�������ݵĸ���
void FRAM_Read(u16 ReadAddr,u8 *pBuffer,u16 NumToRead)
{
	while(NumToRead)
	{
		*pBuffer++ = FRAM_ReadOneByte(ReadAddr++);	
		NumToRead--;
	}	
}

u8 Read_DTU_WKMOD_FRAM(void)
{
	return FRAM_ReadOneByte(WKMOD_ADDR);
}

void Write_DTU_WKMOD_FRAM(u8 data)
{
	FRAM_WriteOneByte(WKMOD_ADDR,data);
}

u32 Read_DTU_BAUDRATE_FRAM(void)
{
	u8 rBuffer[4];
	u32 number;
	
	FRAM_Read(BAUDRATE_ADDR,rBuffer,4);
	
	number = rBuffer[0];
	number <<= 8;
	number += rBuffer[1];
	number <<= 8;	
	number += rBuffer[2];
	number <<= 8;	
	number += rBuffer[3];
	
	return number;
}

void Write_DTU_BAUDRATE_FRAM(u32 data)
{
	u8 wBuffer[4];
	wBuffer[0] = (data >> 24) & 0xFF;
	wBuffer[1] = (data >> 16) & 0xFF;
	wBuffer[2] = (data >> 8) & 0xFF;
	wBuffer[3] = (data >> 0) & 0xFF;
	FRAM_Write(BAUDRATE_ADDR,wBuffer,4);
}

//TCP UDP ������
u8 Read_DTU_HEART_EN_FRAM(void)
{
	return FRAM_ReadOneByte(HEART_EN_ADDR);
}

void Write_DTU_HEART_EN_FRAM(u8 data)
{
	FRAM_WriteOneByte(HEART_EN_ADDR,data);
} 

u32 Read_DTU_HEART_TIME_FRAM(void)
{
	u8 rBuffer[4];
	u32 number;
	
	FRAM_Read(HEART_TIME_ADDR,rBuffer,4);
	
	number = rBuffer[0];
	number <<= 8;
	number += rBuffer[1];
	number <<= 8;	
	number += rBuffer[2];
	number <<= 8;	
	number += rBuffer[3];
	
	return number;
}

void Write_DTU_HEART_TIME_FRAM(u32 data)
{
	u8 wBuffer[4];
	wBuffer[0] = (data >> 24) ;
	wBuffer[1] = (data >> 16) ;
	wBuffer[2] = (data >> 8) ;
	wBuffer[3] = (data >> 0) ;
	FRAM_Write(HEART_TIME_ADDR,wBuffer,4);
}

void Read_DTU_HEART_DATA_FRAM(u8 *pBuffer)
{
	FRAM_Read(HEART_DATA_ADDR,pBuffer,100);
}

void Write_DTU_HEART_DATA_FRAM(u8 *pBuffer)
{
	FRAM_Write(HEART_DATA_ADDR,pBuffer,100);
}


//��������
void Read_DTU_CMD_PW_FRAM(u8 *pBuffer)
{
	FRAM_Read(CMD_PW_ADDR,pBuffer,20);
}

void Write_DTU_CMD_PW_FRAM(u8 *pBuffer)
{
	FRAM_Write(CMD_PW_ADDR,pBuffer,20);
}

//DTU_START_EN
u8 Read_DTU_START_EN_FRAM(void)
{
	return FRAM_ReadOneByte(START_EN_ADDR);
}

void Write_DTU_START_EN_FRAM(u8 data)
{
	FRAM_WriteOneByte(START_EN_ADDR,data);
} 

//DTU_START_LOG
void Read_DTU_START_LOG_FRAM(u8 *pBuffer)
{
	FRAM_Read(HEART_DATA_ADDR,pBuffer,20);
}

void Write_START_LOG_ADDR_FRAM(u8 *pBuffer)
{
	FRAM_Write(HEART_DATA_ADDR,pBuffer,20);
}

//TCP
void Read_DTU_TCP_IPADDR_FRAM(u8 *pBuffer)
{
	FRAM_Read(TCP_IPADDR_ADDR,pBuffer,100);
}

void Write_DTU_TCP_IPADDR_FRAM(u8 *pBuffer)
{
	FRAM_Write(TCP_IPADDR_ADDR,pBuffer,100);
}

void Read_DTU_TCP_PORT_FRAM(u8 *pBuffer)
{
	FRAM_Read(TCP_PORT_ADDR,pBuffer,6);
}

void Write_DTU_TCP_PORT_FRAM(u8 *pBuffer)
{
	FRAM_Write(TCP_PORT_ADDR,pBuffer,6);
}

//UDP
void Read_DTU_UDP_IPADDR_FRAM(u8 *pBuffer)
{
	FRAM_Read(UDP_IPADDR_ADDR,pBuffer,100);
}

void Write_DTU_UDP_IPADDR_FRAM(u8 *pBuffer)
{
	FRAM_Write(UDP_IPADDR_ADDR,pBuffer,100);
}

void Read_DTU_UDP_PORT_FRAM(u8 *pBuffer)
{
	FRAM_Read(UDP_PORT_ADDR,pBuffer,6);
}

void Write_DTU_UDP_PORT_FRAM(u8 *pBuffer)
{
	FRAM_Write(UDP_PORT_ADDR,pBuffer,6);
}
//SMS
void Read_DTU_SMS_PHONE_FRAM(u8 *pBuffer)
{
	FRAM_Read(DTU_SMS_PHONE_ADDR,pBuffer,20);
}

void Write_DTU_SMS_PHONE_FRAM(u8 *pBuffer)
{
	FRAM_Write(DTU_SMS_PHONE_ADDR,pBuffer,20);
}
//BT
void Read_DTU_BT_NAME_FRAM(u8 *pBuffer)
{
	FRAM_Read(DTU_BT_NAME_ADDR,pBuffer,10);
}

void Write_DTU_BT_NAME_FRAM(u8 *pBuffer)
{
	FRAM_Write(DTU_BT_NAME_ADDR,pBuffer,10);
}

u8 Read_DTU_NATEN_FRAM(void)
{
	return FRAM_ReadOneByte(DTU_NATEN_ADDR);
}

void Write_DTU_NATEN_FRAM(u8 data)
{
	FRAM_WriteOneByte(DTU_NATEN_ADDR,data);
}

u8 Read_DTU_UATEN_FRAM(void)
{
	return FRAM_ReadOneByte(DTU_UATEN_ADDR);
}

void Write_DTU_UATEN_FRAM(u8 data)
{
	FRAM_WriteOneByte(DTU_UATEN_ADDR,data);
}

void DTU_FRAM_Reset_Admin(void)
{
	u8	DTU_RUNMODE 		= 	DTU_AT;

	u32	DTU_BAUDRATE		=	115200;

	u8	DTU_HEART_EN 		= 	1;						//1��ʹ�� 
	u32	DTU_HEART_TIME 		= 	30;
	u8	DTU_HEART_DATA[100]	=	"www.ruibake.com";

	u8	DTU_CMD_PW[20]		=	"ruibake.com";

	u8	DTU_START_EN		=	1;
	u8	DTU_START_LOG[20]	=	"ruibake DTU";

	u8	DTU_TCP_IPADDR[100]	=	"www.ruibake.com";
	u8	DTU_TCP_PORT[6]		=	"30000";

	u8	DTU_UDP_IPADDR[100]	=	"www.ruibake.com";
	u8	DTU_UDP_PORT[6]		=	"31000";

	u8	DTU_SMS_PHONE[20]	=	"18752028956";

	u8	DTU_BT_NAME[10]		=	"RBK_DTU";

	u8	DTU_NATEN			=	1;
	u8	DTU_UATEN			=	1;
	
	Write_DTU_WKMOD_FRAM(DTU_RUNMODE);
	Write_DTU_BAUDRATE_FRAM(DTU_BAUDRATE);
	Write_DTU_HEART_EN_FRAM(DTU_HEART_EN);
	Write_DTU_HEART_TIME_FRAM(DTU_HEART_TIME);
	
	Write_DTU_HEART_DATA_FRAM(DTU_HEART_DATA);
	Write_DTU_CMD_PW_FRAM(DTU_CMD_PW);
	
	Write_DTU_START_EN_FRAM(DTU_START_EN);
	Write_START_LOG_ADDR_FRAM(DTU_START_LOG);
	Write_DTU_TCP_IPADDR_FRAM(DTU_TCP_IPADDR);
	Write_DTU_TCP_PORT_FRAM(DTU_TCP_PORT);
	Write_DTU_UDP_IPADDR_FRAM(DTU_UDP_IPADDR);
	Write_DTU_UDP_PORT_FRAM(DTU_UDP_PORT);
	Write_DTU_SMS_PHONE_FRAM(DTU_SMS_PHONE);
	Write_DTU_BT_NAME_FRAM(DTU_BT_NAME);
	
	Write_DTU_NATEN_FRAM(DTU_NATEN);
	Write_DTU_UATEN_FRAM(DTU_UATEN);	

	
}

void DTU_FRAM_Reset_User_Read(void)
{
	deviation = 1;
	DTU_FRAM_Read();
	deviation = 0;
}

void DTU_FRAM_Reset_User_Write(void)
{
	deviation = 1;
	DTU_FRAM_Write();
	deviation = 0;
	DTU_FRAM_Write();
}

void DTU_FRAM_Write(void)
{
	
	Write_DTU_WKMOD_FRAM(DTU_RUNMODE);
	Write_DTU_BAUDRATE_FRAM(DTU_BAUDRATE);
	Write_DTU_HEART_EN_FRAM(DTU_HEART_EN);
	Write_DTU_HEART_TIME_FRAM(DTU_HEART_TIME);
	
	Write_DTU_HEART_DATA_FRAM(DTU_HEART_DATA);
	Write_DTU_CMD_PW_FRAM(DTU_CMD_PW);
	
	Write_DTU_START_EN_FRAM(DTU_START_EN);
	Write_START_LOG_ADDR_FRAM(DTU_START_LOG);
	Write_DTU_TCP_IPADDR_FRAM(DTU_TCP_IPADDR);
	Write_DTU_TCP_PORT_FRAM(DTU_TCP_PORT);
	Write_DTU_UDP_IPADDR_FRAM(DTU_UDP_IPADDR);
	Write_DTU_UDP_PORT_FRAM(DTU_UDP_PORT);
	Write_DTU_SMS_PHONE_FRAM(DTU_SMS_PHONE);
	Write_DTU_BT_NAME_FRAM(DTU_BT_NAME);
	
	Write_DTU_NATEN_FRAM(DTU_NATEN);
	Write_DTU_UATEN_FRAM(DTU_UATEN);
}



void DTU_FRAM_Read(void)
{

	DTU_RUNMODE		=	Read_DTU_WKMOD_FRAM();
	DTU_BAUDRATE	=	Read_DTU_BAUDRATE_FRAM();
	DTU_HEART_EN	=	Read_DTU_HEART_EN_FRAM();
	DTU_HEART_TIME	=	Read_DTU_HEART_TIME_FRAM();
	
	Read_DTU_HEART_DATA_FRAM(DTU_HEART_DATA);
	Read_DTU_CMD_PW_FRAM(DTU_CMD_PW);
	
	DTU_START_EN = Read_DTU_START_EN_FRAM();
	
	Read_DTU_START_LOG_FRAM(DTU_START_LOG);
	Read_DTU_TCP_IPADDR_FRAM(DTU_TCP_IPADDR);
	Read_DTU_TCP_PORT_FRAM(DTU_TCP_PORT);
	Read_DTU_UDP_IPADDR_FRAM(DTU_UDP_IPADDR);
	Read_DTU_UDP_PORT_FRAM(DTU_UDP_PORT);
	Read_DTU_SMS_PHONE_FRAM(DTU_SMS_PHONE);
	Read_DTU_BT_NAME_FRAM(DTU_BT_NAME);
	
	DTU_NATEN = Read_DTU_NATEN_FRAM();
	DTU_UATEN = Read_DTU_UATEN_FRAM();
	
	printf("DTU_RUNMODE:%d\r\n",DTU_RUNMODE);
	printf("DTU_BAUDRATE:%u\r\n",DTU_BAUDRATE);
	printf("DTU_HEART_EN:%d\r\n",DTU_HEART_EN);
	printf("DTU_HEART_TIME:%u\r\n",DTU_HEART_TIME);
	printf("DTU_HEART_DATA:%s\r\n",DTU_HEART_DATA);
	printf("DTU_CMD_PW:%s\r\n",DTU_CMD_PW);
	printf("DTU_START_EN:%d\r\n",DTU_START_EN);
	printf("DTU_START_LOG:%s\r\n",DTU_START_LOG);
	
	printf("DTU_TCP_IPADDR:%s\r\n",DTU_TCP_IPADDR);
	printf("DTU_TCP_PORT:%s\r\n",DTU_TCP_PORT);
	printf("DTU_UDP_IPADDR:%s\r\n",DTU_UDP_IPADDR);
	printf("DTU_UDP_PORT:%s\r\n",DTU_UDP_PORT);
	printf("DTU_SMS_PHONE:%s\r\n",DTU_SMS_PHONE);
	printf("DTU_BT_NAME:%s\r\n",DTU_BT_NAME);

	printf("DTU_NATEN:%d\r\n",DTU_NATEN);
	printf("DTU_UATEN:%d\r\n",DTU_UATEN);
}
