#ifndef	_DTU_SMS_H_
#define	_DTU_SMS_H_

void DTU_SMS_WORK(void);

void dtu_sms_printf(char* fmt);

#endif 
