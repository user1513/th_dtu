
#ifndef	_DTU_SIM800C_H_
#define	_DTU_SIM800C_H_

#include "sim800c.h"


#define swap16(x) (x&0XFF)<<8|(x&0XFF00)>>8	//�ߵ��ֽڽ����궨��


#define DTU_AT			10

#define DTU_GPRS_TCP	1
#define DTU_GPRS_UDP	2


extern u8 DTU_Mode;

void ntp_update(void);
void DTU_AT_WORK(void);
void DTU_GPRS_TCP_WORK(void);
void DTU_GPRS_UDP_WORK(void);

#endif 
