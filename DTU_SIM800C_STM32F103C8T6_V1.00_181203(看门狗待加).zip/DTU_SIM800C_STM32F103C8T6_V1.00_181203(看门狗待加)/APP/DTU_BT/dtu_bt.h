#ifndef	_DTU_BT_H_
#define	_DTU_BT_H_


void DTU_SPP_WORK(void);


void dtu_spp_printf(char* fmt);

#endif 
